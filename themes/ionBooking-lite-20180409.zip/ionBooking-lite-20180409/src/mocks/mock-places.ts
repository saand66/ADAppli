export let PLACES = []
